import React from 'react';
import { SiemensSlide } from './components/SiemensSlide';
export function App() {
  return <SiemensSlide />;
}