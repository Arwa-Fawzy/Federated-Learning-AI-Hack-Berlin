import React from 'react';
export function ValueBullets() {
  const bullets = ['+15% higher anomaly detection vs isolated local models', '20× lower bandwidth usage (no raw sensor logs transmitted)', '100% data privacy — data stays fully local on each client'];
  return <div className="mb-8">
      <div className="flex flex-col md:flex-row gap-4 md:gap-8 justify-between">
        {bullets.map((bullet, index) => <div key={index} className="flex items-start">
            <div className="w-3 h-3 mt-1.5 rounded-full bg-[#009999] mr-3"></div>
            <p className="text-[#333333] font-light text-lg">{bullet}</p>
          </div>)}
      </div>
    </div>;
}