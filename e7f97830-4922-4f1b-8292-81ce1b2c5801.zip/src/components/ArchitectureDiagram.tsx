import React from 'react';
export function ArchitectureDiagram() {
  return <div className="w-full max-w-md">
      <svg viewBox="0 0 400 320" className="w-full">
        {/* Global Model */}
        <rect x="150" y="10" width="100" height="40" rx="2" fill="#009999" fillOpacity="0.1" stroke="#009999" strokeWidth="1.5" />
        <text x="200" y="35" textAnchor="middle" fontSize="14" fill="#333333" fontWeight="400">
          Global Model
        </text>
        {/* Arrow down */}
        <path d="M200 50 L200 80" stroke="#009999" strokeWidth="1.5" markerEnd="url(#arrowhead)" />
        {/* Federated Server */}
        <rect x="125" y="80" width="150" height="50" rx="2" fill="#009999" fillOpacity="0.2" stroke="#009999" strokeWidth="1.5" />
        <text x="200" y="105" textAnchor="middle" fontSize="14" fill="#333333" fontWeight="400">
          Federated Server
        </text>
        <text x="200" y="120" textAnchor="middle" fontSize="12" fill="#555555" fontWeight="300">
          (Flower)
        </text>
        {/* Arrows to clients */}
        <path d="M140 130 L80 170" stroke="#009999" strokeWidth="1.5" markerEnd="url(#arrowhead)" />
        <path d="M200 130 L200 170" stroke="#009999" strokeWidth="1.5" markerEnd="url(#arrowhead)" />
        <path d="M260 130 L320 170" stroke="#009999" strokeWidth="1.5" markerEnd="url(#arrowhead)" />
        {/* FL Clients */}
        <rect x="30" y="170" width="100" height="40" rx="2" fill="#009999" fillOpacity="0.1" stroke="#009999" strokeWidth="1.5" />
        <text x="80" y="195" textAnchor="middle" fontSize="13" fill="#333333" fontWeight="400">
          FL Client 1
        </text>
        <rect x="150" y="170" width="100" height="40" rx="2" fill="#009999" fillOpacity="0.1" stroke="#009999" strokeWidth="1.5" />
        <text x="200" y="195" textAnchor="middle" fontSize="13" fill="#333333" fontWeight="400">
          FL Client 2
        </text>
        <rect x="270" y="170" width="100" height="40" rx="2" fill="#009999" fillOpacity="0.1" stroke="#009999" strokeWidth="1.5" />
        <text x="320" y="195" textAnchor="middle" fontSize="13" fill="#333333" fontWeight="400">
          FL Client 3
        </text>
        {/* Arrows to sensors */}
        <path d="M80 210 L80 250" stroke="#009999" strokeWidth="1.5" markerEnd="url(#arrowhead)" />
        <path d="M200 210 L200 250" stroke="#009999" strokeWidth="1.5" markerEnd="url(#arrowhead)" />
        <path d="M320 210 L320 250" stroke="#009999" strokeWidth="1.5" markerEnd="url(#arrowhead)" />
        {/* Sensors */}
        <rect x="30" y="250" width="100" height="40" rx="2" fill="white" stroke="#009999" strokeWidth="1.5" />
        <text x="80" y="275" textAnchor="middle" fontSize="13" fill="#333333" fontWeight="400">
          Sensors 1.x
        </text>
        <rect x="150" y="250" width="100" height="40" rx="2" fill="white" stroke="#009999" strokeWidth="1.5" />
        <text x="200" y="275" textAnchor="middle" fontSize="13" fill="#333333" fontWeight="400">
          Sensors 2.x
        </text>
        <rect x="270" y="250" width="100" height="40" rx="2" fill="white" stroke="#009999" strokeWidth="1.5" />
        <text x="320" y="275" textAnchor="middle" fontSize="13" fill="#333333" fontWeight="400">
          Sensors 3.x
        </text>
        {/* Arrow definition */}
        <defs>
          <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
            <polygon points="0 0, 10 3.5, 0 7" fill="#009999" />
          </marker>
        </defs>
      </svg>
    </div>;
}