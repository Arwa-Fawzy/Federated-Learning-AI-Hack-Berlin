import React from 'react';
export function PerformanceChart() {
  // Sample data for the chart
  const rounds = [1, 2, 3, 4, 5, 6];
  const accuracy = [0.89017, 0.89013, 0.89015, 0.89031, 0.89018, 0.89025];
  const loss = [1.02868, 1.02898, 1.02774, 1.02863, 1.02831, 1.02811];
  // Chart dimensions - increased padding to prevent overlaps
  const width = 450;
  const height = 280;
  const padding = 60;
  // Scale values
  const xScale = i => padding + i / (rounds.length - 1) * (width - 2 * padding);
  const yScaleLoss = value => height - padding - (value - 1.0277) / (1.029 - 1.0277) * (height - 2 * padding);
  const yScaleAcc = value => height - padding - (value - 0.8901) / (0.89035 - 0.8901) * (height - 2 * padding);
  // Generate path data
  const lossPath = rounds.map((_, i) => `${i === 0 ? 'M' : 'L'} ${xScale(i)} ${yScaleLoss(loss[i])}`).join(' ');
  const accuracyPath = rounds.map((_, i) => `${i === 0 ? 'M' : 'L'} ${xScale(i)} ${yScaleAcc(accuracy[i])}`).join(' ');
  // Y-axis values for loss
  const lossYValues = [1.0277, 1.0281, 1.0285, 1.0289];
  return <div className="w-full max-w-md">
      <div className="text-center text-lg font-light mb-6">
        Federated Drift Twin: Global Loss & Accuracy per Round
      </div>
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full">
        {/* Horizontal grid lines */}
        {lossYValues.map((value, i) => <line key={`grid-${i}`} x1={padding} y1={yScaleLoss(value)} x2={width - padding} y2={yScaleLoss(value)} stroke="#e0e0e0" strokeWidth="1" strokeDasharray="3,3" />)}
        {/* X and Y axes */}
        <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#333333" strokeWidth="1" />
        <line x1={padding} y1={padding} x2={padding} y2={height - padding} stroke="#333333" strokeWidth="1" />
        {/* Y-axis labels for loss */}
        {lossYValues.map((value, i) => <g key={`y-${i}`}>
            <line x1={padding - 5} y1={yScaleLoss(value)} x2={padding} y2={yScaleLoss(value)} stroke="#333333" strokeWidth="1" />
            <text x={padding - 12} y={yScaleLoss(value) + 4} textAnchor="end" fontSize="10" fill="#009999">
              {value.toFixed(4)}
            </text>
          </g>)}
        {/* X-axis labels */}
        {rounds.map((round, i) => <g key={`x-${i}`}>
            <line x1={xScale(i)} y1={height - padding} x2={xScale(i)} y2={height - padding + 5} stroke="#333333" strokeWidth="1" />
            <text x={xScale(i)} y={height - padding + 20} textAnchor="middle" fontSize="11" fill="#555555">
              {round}
            </text>
          </g>)}
        {/* Axis labels with increased spacing */}
        <text x={width / 2} y={height - 5} textAnchor="middle" fontSize="12" fill="#555555">
          Round
        </text>
        <text x={12} y={height / 2} textAnchor="middle" fontSize="11" fill="#009999" transform={`rotate(-90, 12, ${height / 2})`}>
          Global Loss (MSE)
        </text>
        <text x={width - 12} y={height / 2} textAnchor="middle" fontSize="11" fill="#FF8C00" transform={`rotate(90, ${width - 12}, ${height / 2})`}>
          Global Accuracy
        </text>
        {/* Data lines */}
        <path d={lossPath} fill="none" stroke="#009999" strokeWidth="2" />
        <path d={accuracyPath} fill="none" stroke="#FF8C00" strokeWidth="2" strokeDasharray="5,5" />
        {/* Data points */}
        {rounds.map((_, i) => <g key={`point-${i}`}>
            <circle cx={xScale(i)} cy={yScaleLoss(loss[i])} r="3.5" fill="#009999" />
            <circle cx={xScale(i)} cy={yScaleAcc(accuracy[i])} r="3.5" fill="#FF8C00" />
          </g>)}
        {/* End of line value labels */}
        <text x={xScale(rounds.length - 1) + 15} y={yScaleLoss(loss[loss.length - 1]) + 4} fontSize="11" fill="#009999" fontWeight="500">
          1.02811
        </text>
        <text x={xScale(rounds.length - 1) + 15} y={yScaleAcc(accuracy[accuracy.length - 1]) + 4} fontSize="11" fill="#FF8C00" fontWeight="500">
          89%
        </text>
        {/* Legend */}
        <circle cx={width - padding - 120} cy={padding + 15} r="3.5" fill="#009999" />
        <text x={width - padding - 110} y={padding + 18} fontSize="10" fill="#555555">
          Global Loss
        </text>
        <circle cx={width - padding - 120} cy={padding + 33} r="3.5" fill="#FF8C00" />
        <text x={width - padding - 110} y={padding + 36} fontSize="10" fill="#555555">
          Global Accuracy
        </text>
      </svg>
    </div>;
}