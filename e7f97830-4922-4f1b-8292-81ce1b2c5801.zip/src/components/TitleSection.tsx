import React from 'react';
export function TitleSection() {
  return <div className="mb-8">
      <h1 className="text-center text-3xl md:text-4xl font-light tracking-tight mb-2">
        Manufacturing data is broken — causing massive productivity losses
        across industries.
      </h1>
      <div className="w-48 h-0.5 bg-[#009999] mx-auto mb-3"></div>
      <h2 className="text-center text-xl md:text-2xl font-light text-[#555555]">
        Federated Predictive Maintenance powered by the Flower Framework.
      </h2>
    </div>;
}