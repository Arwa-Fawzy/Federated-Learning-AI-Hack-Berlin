import React from 'react';
export function ClientDataTable() {
  const clientData = [{
    client: 0,
    train: 8196,
    test: 2194,
    features: 52,
    lastLoss: 0.944039,
    lastAcc: '92.16%'
  }, {
    client: 1,
    train: 52482,
    test: 15413,
    features: 45,
    lastLoss: 1.062047,
    lastAcc: '83.58%'
  }, {
    client: 2,
    train: 23043,
    test: 6600,
    features: 35,
    lastLoss: 1.072897,
    lastAcc: '85.91%'
  }, {
    client: 3,
    train: 44974,
    test: 13210,
    features: 25,
    lastLoss: 0.993543,
    lastAcc: '84.60%'
  }, {
    client: 4,
    train: 26289,
    test: 6600,
    features: 20,
    lastLoss: 1.070081,
    lastAcc: '98.83%'
  }];
  return <div className="border border-[#009999] rounded overflow-hidden">
      <table className="w-full text-xs">
        <thead>
          <tr className="bg-[#009999] bg-opacity-10">
            <th className="py-3 px-4 text-left font-light text-[#333333] border-r border-[#009999]">
              Client
            </th>
            <th className="py-3 px-4 text-left font-light text-[#333333] border-r border-[#009999]">
              Train
            </th>
            <th className="py-3 px-4 text-left font-light text-[#333333] border-r border-[#009999]">
              Test
            </th>
            <th className="py-3 px-4 text-left font-light text-[#333333] border-r border-[#009999]">
              Features
            </th>
            <th className="py-3 px-4 text-left font-light text-[#333333] border-r border-[#009999]">
              Last Loss
            </th>
            <th className="py-3 px-4 text-left font-light text-[#333333]">
              Last Acc
            </th>
          </tr>
        </thead>
        <tbody>
          {clientData.map((row, index) => <tr key={row.client} className={index % 2 === 0 ? 'bg-white' : 'bg-[#f8f8f8]'}>
              <td className="py-2 px-4 font-light border-r border-[#e0e0e0]">
                {row.client}
              </td>
              <td className="py-2 px-4 font-light border-r border-[#e0e0e0]">
                {row.train.toLocaleString()}
              </td>
              <td className="py-2 px-4 font-light border-r border-[#e0e0e0]">
                {row.test.toLocaleString()}
              </td>
              <td className="py-2 px-4 font-light border-r border-[#e0e0e0]">
                {row.features}
              </td>
              <td className="py-2 px-4 font-light border-r border-[#e0e0e0]">
                {row.lastLoss.toFixed(6)}
              </td>
              <td className="py-2 px-4 font-light">{row.lastAcc}</td>
            </tr>)}
        </tbody>
      </table>
    </div>;
}