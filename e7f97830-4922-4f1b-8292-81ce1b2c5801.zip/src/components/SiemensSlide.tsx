import React from 'react';
import { TitleSection } from './TitleSection';
import { ContentSection } from './ContentSection';
import { ValueBullets } from './ValueBullets';
import { Footer } from './Footer';
export function SiemensSlide() {
  return <div className="flex flex-col w-full min-h-screen bg-white text-[#333333] font-sans">
      <div className="flex-1 flex flex-col p-10 max-w-7xl mx-auto w-full">
        <TitleSection />
        <ContentSection />
        <ValueBullets />
        <Footer />
      </div>
    </div>;
}