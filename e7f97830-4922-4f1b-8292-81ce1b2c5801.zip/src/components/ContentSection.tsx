import React from 'react';
import { ArchitectureDiagram } from './ArchitectureDiagram';
import { PerformanceChart } from './PerformanceChart';
import { ClientDataTable } from './ClientDataTable';
export function ContentSection() {
  return <div className="flex flex-col gap-8 mb-12">
      {/* Top row: Chart on left, Pump on right */}
      <div className="flex flex-col md:flex-row gap-8 items-center justify-center">
        <div className="flex flex-col items-center">
          <PerformanceChart />
          <p className="text-[#009999] text-sm mt-2 max-w-md text-center">
            Global model improves collaboratively—without sharing raw data.
          </p>
        </div>
        <div className="flex flex-col items-center">
          <img src="/Water-Pump-Motor-PNG-File.png" alt="Industrial Pump Motor" className="w-32 h-auto object-contain" />
          <p className="text-[#333333] font-light text-base mt-2">
            SIEMENS Bomb
          </p>
        </div>
      </div>
      {/* Bottom row: Table on left, Architecture on right */}
      <div className="flex flex-col md:flex-row gap-8 items-start justify-center">
        <div className="w-full md:w-1/2">
          <ClientDataTable />
        </div>
        <div className="flex-shrink-0">
          <ArchitectureDiagram />
        </div>
      </div>
    </div>;
}