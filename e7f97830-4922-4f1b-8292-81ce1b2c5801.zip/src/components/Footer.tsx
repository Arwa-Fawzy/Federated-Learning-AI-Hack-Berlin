import React from 'react';
export function Footer() {
  return <div className="mt-auto">
      <div className="h-px bg-[#009999] w-full mb-3"></div>
      <div className="text-[#777777] text-xs">
        Team Sensors · Arwa, Ram, Kazing, Ekaterina
      </div>
      <div className="text-[#777777] text-xs mt-1">
        Federated Predictive Maintenance · Flower Framework
      </div>
      <div className="text-[#777777] text-xs mt-1">
        Berlin Hackathon · 15.11.25
      </div>
    </div>;
}